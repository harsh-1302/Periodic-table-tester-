# Periodic table tester
A program written in Java to test your knowledge about periodic table. 

# Requirements
1. A computer. 😆
2. Any version of JDK.
3. A human being. 🤣

# How to use
1. ```$ git clone https://github.com/dhruvkrishnavaid/periodic-table-tester.git```
2. ```$ javac element.java```
3. ```$ java element```
